sap.ui.define([
	"app/cam/Camera/test/unit/controller/Camera.controller"
], function () {
	"use strict";
});